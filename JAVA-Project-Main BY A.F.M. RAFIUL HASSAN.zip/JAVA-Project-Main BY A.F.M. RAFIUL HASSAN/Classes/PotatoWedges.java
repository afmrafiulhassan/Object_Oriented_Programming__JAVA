package Classes;
public class PotatoWedges extends Foods{
	public PotatoWedges(String name, double price, int quantity, double tax, double discount){
		super(name, price, quantity, tax, discount);
	}
	public void showAll(){
		super.showAll();
	}	
}