package Classes;
public class ChickenWings extends Foods{
	public ChickenWings(String name, double price, int quantity, double tax, double discount){
		super(name, price, quantity, tax, discount);
	}
	public void showAll(){
		super.showAll();
	}	
}